<?php return array('dependencies' => array(), 'version' => 'ac1edb44e0c7550dfdd9');
