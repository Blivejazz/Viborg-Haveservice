export const options = oceanwpLocalize;
